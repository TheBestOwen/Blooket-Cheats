# Santa's Workshop Cheats

## [Remove Distractions](removeDistractions.js)
Removes all enemy distractions

## [Send Distraction](sendDistraction.js)
Sends a distraction to everyone else playing

## [Set Toys](setToys.js)
Sets amount of toys

## [Set Toys Per Question](setToysPerQ.js)
Sets amount of toys per question

## [Swap Toys](swapToys.js)
Swaps toys with someone