# Gold Quest Cheats

## [Always Triple](alwaysTriple.js)
Always get triple gold

## [Auto Choose](autoChoose.js)
Automatically picks the best chest

## [Chest ESP](chestESP.js)
Shows what each chest will give you

## [Reset Player's Gold](resetPlayersGold.js)
Sets a player's gold to 0

## [Reset All Gold](resetAllGold.js)
Set's everyone else's gold to 0

## [Set Gold](setGold.js)
Sets amount of gold

## [Swap Gold](swapGold.js)
Brings up the player select page to swap with someone